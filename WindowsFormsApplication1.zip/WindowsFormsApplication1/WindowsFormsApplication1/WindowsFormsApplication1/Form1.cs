﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading; 

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;

        delegate void DelegateVarious(string frase, string tipo);

        // Inicializacion del datagrid de la lista de conectados
        private void initDataGrid()
        {
            Data.ColumnCount = 1;
            Data.Columns[0].Name = "JUGADORES ONLINE";
        }

        public Form1()
        {
            InitializeComponent();
        }

    
        private void desconectar_Click_1(object sender, EventArgs e)
        {
            string mensaje = "0/";
            // Enviamos al servidor el nombre tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
 
            // Nos desconectamos
            server.Shutdown(SocketShutdown.Both);
            server.Close();
            atender.Abort();
            this.BackColor = Color.Black;
        }

        private void loging_Click(object sender, EventArgs e)
        {
            // Creamos el mensaje para enviar al servidor
            string mensaje = "1/" + usertxt.Text + "/" + passtxt.Text;
            // Enviamos al servidor el nombre tecleado y la contrasena
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void signup_Click_1(object sender, EventArgs e)
        {
            // Creamos el mensaje para enviar al servidor
            string mensaje = "2/" + usertxt.Text + "/" + passtxt.Text;
            // Enviamos al servidor el nombre tecleado y la contrasena
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }


        private void consultas_Click_1(object sender, EventArgs e)
        {
           if (puntuacion.Checked)
                {
                    // Quiere saber los puntos
                    string mensaje = "3/" + nombrepuntuacion.Text;
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
            if (tiempo.Checked)
                {
                    // Quiere saber el tiempo jugado
                    string mensaje = "4/" + nombretiempo.Text;
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                }
                if (ganador.Checked)
                {
                    // Quiere saber el tiempo jugado
                    string mensaje = "5/" + nombre1.Text + "/" + nombre2.Text + "/";
                    // Enviamos al servidor los nombres de los dos jugadores
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                }
             
        }

        private void conectar_Click(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip y puerto del servidor al que queremos conectarnos
            IPAddress direc = IPAddress.Parse(iptxt.Text);
            IPEndPoint ipep = new IPEndPoint(direc, 50001);

            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                //Intentamos conectar el socket
                server.Connect(ipep);
                //Si el servidor se conecta correctamente cambiamos el color de fondo de pantalla
                this.BackColor = Color.LightSeaGreen;
                //Informamos que se ha podido realizar la conexion
                MessageBox.Show("Se ha podido conectar");
            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }

            //Inciamos el thread
            ThreadStart ts = delegate { AtenderServidor(); }; 
            atender = new Thread(ts); 
            atender.Start(); 
        }

        //Funcion para atender el servidor
        private void AtenderServidor()
        {
            while (true)
            {
                byte[] msg2 = new byte[80];
                //Recibimos cualquier tipo de mensaje del servidor
                server.Receive(msg2); 
                //Quitamos informacion no deseada
                string mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                //Procesamos el mensaje
                //El mensaje lo guardamos en un vector de dos posiciones
                string[] trozos = mensaje.Split('/');
                //La primera posicion del mensaje es el codigo
                int codigo = Convert.ToInt32(trozos[0]);
                //Creamos variable para guardar respuesta del servidor
                int respuesta;
                //Analizamos segun el codigo
                switch (codigo)
                {
                    //Log IN
                    case 1: 
                            
                            respuesta = Convert.ToInt32(trozos[1]);
                            if (respuesta == 1)
                            {
                                MessageBox.Show("SUCCESS:Ha podido hacer log in");
                            }
                            else
                            {
                                MessageBox.Show("ERROR: no ha sido posible hacer log in.");
                            }
                            break;
                    // SignUP
                    case 2:
                            respuesta = Convert.ToInt32(trozos[1]);
                            if (respuesta == 1)
                            {
                                MessageBox.Show("SUCCESS:Ha podido hacer sign up");
                            }
                            else
                            {
                                MessageBox.Show("ERROR: no ha sido posible la registracion");
                            }
                            break;
                    //consulta Puntos totales
                    case 3: 
                            respuesta = Convert.ToInt32(trozos[1]);
                            if (respuesta >= 0)
                            {
                                MessageBox.Show("Sus puntos totales" + " son: " + respuesta.ToString());
                            }
                            else
                            {
                                MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                            }
                            break;
                    //Consulta Tiempo Total
                    case 4:
                            respuesta = Convert.ToInt32(trozos[1]);
                           if (respuesta >= 0)
                           {
                                MessageBox.Show("Su tiempo total jugado es:" + respuesta.ToString());
                           }
                           else
                           {
                               MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                           }
                           break;
                    //Consulta cuantas veces ha ganado un jugador a otro
                    case 5: 
                           respuesta = Convert.ToInt32(trozos[1]);
                           if (respuesta >= 0)
                           {
                                MessageBox.Show("Le ha ganado" + " " + respuesta.ToString() + " " + "veces");
                           }
                           else
                           {
                                MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                           }
                           break;
                    //Notificacion para lista de conectados
                    case 6: 
                           string[] mssg;
                           mssg = trozos[1].Split(',');
                           Data.Invoke(new DelegateVarious(PonEnable), new object[] { "", "EliminaNombre" });
                           int rows = Convert.ToInt32(mssg[0]);
                           for (int i = 1; i<=rows; i++)
                           {
                             Data.Invoke(new DelegateVarious(PonEnable), new object[] { mssg[i], "EscribeNombre" });
                           }
                           break;
                    //Recibe una invitacion para jugar
                    case 8: 
                            string player = trozos[1];
                            var result = MessageBox.Show(player + " te ha invitado a jugar. Quieres ACCEPTAR?","Game",MessageBoxButtons.YesNo);
                            string respuestaInvitacion;
                            switch (result)
                            {   
                            case DialogResult.Yes:
                                respuestaInvitacion = "SI";
                                mensaje = "9/" + respuestaInvitacion;
                                break;
                            case DialogResult.No:
                                respuestaInvitacion = "NO";
                                mensaje = "9/" + respuestaInvitacion;
                                break;
                            }
                            // Enviamos al servidor
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                            server.Send(msg);
                            break;
                    //Recibela respuesta de la invitacion
                    case 10:
                            if (trozos[1] == "SI") 
                            {
                                MessageBox.Show("Tu invitacion ha sido ACCEPTADA");
                            }
                            else 
                            {
                                MessageBox.Show("Tu invitacion ha sido RECHAZADA");
                            }
                            break;
                    //Recibe un mensaje del oponente
                    case 11:
                            string oponente = trozos[1];
                            string chat = trozos[2];
                            chatmensaje.Invoke(new DelegateVarious(PonEnable), new object[] { chat, "ChatMensajeLBL" });
                            break;       
                }
            }
        }

        //Funcion PonEnable para solucionar el problema de Cross-Threading
        private void PonEnable(string frase, string tipo)
        {
            //Anadimos al jugador conectado en la lista
            if (tipo == "EscribeNombre") 
            {
                 Data.Rows.Add(frase);
            }
            //Quitaos el jugador desconectado  de la lista
            else if (tipo == "EliminaNombre")
            {
                Data.Rows.Clear();
            }
            //Escribimos el mensaje recibido por el chat en el label correspondiente
            else if (tipo == "ChatMensajeLBL")
            {
                chatmensaje.Visible = true;
                label5.Visible = true;
                chatmensaje.Text = frase;
            }
        }

        //Definimos caracteristicas de la form al cargarse
        private void Form1_Load(object sender, EventArgs e)
        {
            initDataGrid();
            chatmensaje.Visible = false;
            label5.Visible = false;
        }

        //Funcion para definir el control del grid de la lista de conectados
        private void Data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Identificamos la fila que clicamos
            int i = e.RowIndex; 
            //Si se clica en el header no hacer nada
            if (i == -1) return;
            //Guardamos el nombre que selecciona
            string name = Data.Rows[i].Cells[0].Value.ToString(); 

        }

        //Funcion para definir el boton de invitar
        private void invitar_Click(object sender, EventArgs e)
        {
            string mensaje;
            string invitado = "";

            //Si selecciona a un jugador
            if (Data.SelectedRows.Count == 1)
            {
                //Guardamos el nombre de este jugador
                invitado = Data.SelectedRows[0].Cells[0].Value.ToString();
                //Creamos el mensaje para enviar al servidor
                mensaje = "7/" + invitado + "/";
                //Enviamos el mensaje al servidor
                server.Send(System.Text.Encoding.ASCII.GetBytes(mensaje));
            }

            //Notificamos que seleccione a alguien primero
            if (Data.SelectedRows.Count == 0)
                MessageBox.Show("Tienes que seleccionar a alguien para poder invitar");
            //Notificamos que seleccione solo a una persona
            if ((Data.SelectedRows.Count != 0) && (Data.SelectedRows.Count != 1))
                MessageBox.Show("Has seleccionado varios jugadores. Selecciona solo 1");
        }

        //Funcion para definir el boton de enviar un mensaje
        private void Chat_Click(object sender, EventArgs e)
        {
            string oponente = "";
            string mensaje;
            //Si selecciona a un jugador
            if (Data.SelectedRows.Count == 1)
            {
                //Guardamos el nombre de este jugador
                oponente = Data.SelectedRows[0].Cells[0].Value.ToString();
                //Creamos el mensaje para enviar al servidor
                mensaje = "11/" + oponente + "/" + chattxt.Text + "/";
                //Enviamos el mensaje al servidor
                server.Send(System.Text.Encoding.ASCII.GetBytes(mensaje));
            }
            //Notificamos que seleccione a alguien primero si no lo ha hecho
            if (Data.SelectedRows.Count == 0)
                MessageBox.Show("Tienes que seleccionar a alguien para poder invitar");
            //Notificamos que seleccione solo a una persona en caso de seleccionar varias
            if ((Data.SelectedRows.Count != 0) && (Data.SelectedRows.Count != 1))
                MessageBox.Show("Has seleccionado varios jugadores. Selecciona solo 1");
        }
    }
}
