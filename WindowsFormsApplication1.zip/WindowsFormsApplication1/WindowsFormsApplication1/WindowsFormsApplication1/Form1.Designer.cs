﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.conectar = new System.Windows.Forms.Button();
            this.desconectar = new System.Windows.Forms.Button();
            this.iptxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.usertxt = new System.Windows.Forms.TextBox();
            this.user = new System.Windows.Forms.Label();
            this.pass = new System.Windows.Forms.Label();
            this.passtxt = new System.Windows.Forms.TextBox();
            this.loging = new System.Windows.Forms.Button();
            this.signup = new System.Windows.Forms.Button();
            this.ganador = new System.Windows.Forms.RadioButton();
            this.puntuacion = new System.Windows.Forms.RadioButton();
            this.tiempo = new System.Windows.Forms.RadioButton();
            this.consultas = new System.Windows.Forms.Button();
            this.nombre1 = new System.Windows.Forms.TextBox();
            this.jugador1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chattxt = new System.Windows.Forms.TextBox();
            this.nombre2 = new System.Windows.Forms.TextBox();
            this.nombrepuntuacion = new System.Windows.Forms.TextBox();
            this.nombretiempo = new System.Windows.Forms.TextBox();
            this.Data = new System.Windows.Forms.DataGridView();
            this.invitar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Chat = new System.Windows.Forms.Button();
            this.chatmensaje = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Data)).BeginInit();
            this.SuspendLayout();
            // 
            // conectar
            // 
            this.conectar.BackColor = System.Drawing.Color.LightPink;
            this.conectar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conectar.ForeColor = System.Drawing.Color.DimGray;
            this.conectar.Location = new System.Drawing.Point(45, 90);
            this.conectar.Name = "conectar";
            this.conectar.Size = new System.Drawing.Size(84, 31);
            this.conectar.TabIndex = 5;
            this.conectar.Text = "Conectar";
            this.conectar.UseVisualStyleBackColor = false;
            this.conectar.Click += new System.EventHandler(this.conectar_Click);
            // 
            // desconectar
            // 
            this.desconectar.BackColor = System.Drawing.Color.LightPink;
            this.desconectar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.desconectar.ForeColor = System.Drawing.Color.DimGray;
            this.desconectar.Location = new System.Drawing.Point(144, 91);
            this.desconectar.Margin = new System.Windows.Forms.Padding(2);
            this.desconectar.Name = "desconectar";
            this.desconectar.Size = new System.Drawing.Size(87, 30);
            this.desconectar.TabIndex = 8;
            this.desconectar.Text = "Desconectar";
            this.desconectar.UseVisualStyleBackColor = false;
            this.desconectar.Click += new System.EventHandler(this.desconectar_Click_1);
            // 
            // iptxt
            // 
            this.iptxt.Location = new System.Drawing.Point(91, 55);
            this.iptxt.Name = "iptxt";
            this.iptxt.Size = new System.Drawing.Size(86, 20);
            this.iptxt.TabIndex = 9;
            this.iptxt.Text = "147.83.117.22";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label1.Location = new System.Drawing.Point(54, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Introduce direccion IP";
            // 
            // usertxt
            // 
            this.usertxt.Location = new System.Drawing.Point(91, 193);
            this.usertxt.Name = "usertxt";
            this.usertxt.Size = new System.Drawing.Size(117, 20);
            this.usertxt.TabIndex = 11;
            // 
            // user
            // 
            this.user.AutoSize = true;
            this.user.Location = new System.Drawing.Point(54, 196);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(32, 13);
            this.user.TabIndex = 12;
            this.user.Text = "User:";
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.Location = new System.Drawing.Point(29, 232);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(56, 13);
            this.pass.TabIndex = 13;
            this.pass.Text = "Password:";
            // 
            // passtxt
            // 
            this.passtxt.Location = new System.Drawing.Point(91, 229);
            this.passtxt.Name = "passtxt";
            this.passtxt.Size = new System.Drawing.Size(117, 20);
            this.passtxt.TabIndex = 14;
            // 
            // loging
            // 
            this.loging.BackColor = System.Drawing.Color.LightPink;
            this.loging.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loging.ForeColor = System.Drawing.Color.DimGray;
            this.loging.Location = new System.Drawing.Point(70, 264);
            this.loging.Name = "loging";
            this.loging.Size = new System.Drawing.Size(74, 23);
            this.loging.TabIndex = 15;
            this.loging.Text = "Log in";
            this.loging.UseVisualStyleBackColor = false;
            this.loging.Click += new System.EventHandler(this.loging_Click);
            // 
            // signup
            // 
            this.signup.BackColor = System.Drawing.Color.LightPink;
            this.signup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signup.ForeColor = System.Drawing.Color.DimGray;
            this.signup.Location = new System.Drawing.Point(157, 264);
            this.signup.Name = "signup";
            this.signup.Size = new System.Drawing.Size(74, 23);
            this.signup.TabIndex = 16;
            this.signup.Text = "Sign Up";
            this.signup.UseVisualStyleBackColor = false;
            this.signup.Click += new System.EventHandler(this.signup_Click_1);
            // 
            // ganador
            // 
            this.ganador.AutoSize = true;
            this.ganador.Checked = true;
            this.ganador.Location = new System.Drawing.Point(360, 42);
            this.ganador.Name = "ganador";
            this.ganador.Size = new System.Drawing.Size(272, 17);
            this.ganador.TabIndex = 17;
            this.ganador.TabStop = true;
            this.ganador.Text = "Cuantas veces ha ganado el jugador 1 al jugador 2?";
            this.ganador.UseVisualStyleBackColor = true;
            // 
            // puntuacion
            // 
            this.puntuacion.AutoSize = true;
            this.puntuacion.Location = new System.Drawing.Point(360, 118);
            this.puntuacion.Name = "puntuacion";
            this.puntuacion.Size = new System.Drawing.Size(157, 17);
            this.puntuacion.TabIndex = 18;
            this.puntuacion.Text = "Puntuacion total del jugador";
            this.puntuacion.UseVisualStyleBackColor = true;
            // 
            // tiempo
            // 
            this.tiempo.AutoSize = true;
            this.tiempo.Location = new System.Drawing.Point(360, 147);
            this.tiempo.Name = "tiempo";
            this.tiempo.Size = new System.Drawing.Size(203, 17);
            this.tiempo.TabIndex = 19;
            this.tiempo.Text = "Tiempo total que ha jugado el jugador";
            this.tiempo.UseVisualStyleBackColor = true;
            // 
            // consultas
            // 
            this.consultas.BackColor = System.Drawing.Color.LightPink;
            this.consultas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.consultas.ForeColor = System.Drawing.Color.DimGray;
            this.consultas.Location = new System.Drawing.Point(468, 170);
            this.consultas.Name = "consultas";
            this.consultas.Size = new System.Drawing.Size(75, 23);
            this.consultas.TabIndex = 20;
            this.consultas.Text = "Enviar";
            this.consultas.UseVisualStyleBackColor = false;
            this.consultas.Click += new System.EventHandler(this.consultas_Click_1);
            // 
            // nombre1
            // 
            this.nombre1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre1.Location = new System.Drawing.Point(459, 70);
            this.nombre1.Name = "nombre1";
            this.nombre1.Size = new System.Drawing.Size(123, 20);
            this.nombre1.TabIndex = 21;
            // 
            // jugador1
            // 
            this.jugador1.AutoSize = true;
            this.jugador1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador1.Location = new System.Drawing.Point(394, 70);
            this.jugador1.Name = "jugador1";
            this.jugador1.Size = new System.Drawing.Size(59, 15);
            this.jugador1.TabIndex = 22;
            this.jugador1.Text = "Player 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(394, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "Player 2";
            // 
            // chattxt
            // 
            this.chattxt.Location = new System.Drawing.Point(53, 356);
            this.chattxt.Name = "chattxt";
            this.chattxt.Size = new System.Drawing.Size(155, 20);
            this.chattxt.TabIndex = 24;
            // 
            // nombre2
            // 
            this.nombre2.Location = new System.Drawing.Point(458, 93);
            this.nombre2.Margin = new System.Windows.Forms.Padding(2);
            this.nombre2.Name = "nombre2";
            this.nombre2.Size = new System.Drawing.Size(123, 20);
            this.nombre2.TabIndex = 25;
            // 
            // nombrepuntuacion
            // 
            this.nombrepuntuacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombrepuntuacion.Location = new System.Drawing.Point(569, 118);
            this.nombrepuntuacion.Name = "nombrepuntuacion";
            this.nombrepuntuacion.Size = new System.Drawing.Size(123, 20);
            this.nombrepuntuacion.TabIndex = 26;
            // 
            // nombretiempo
            // 
            this.nombretiempo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombretiempo.Location = new System.Drawing.Point(569, 144);
            this.nombretiempo.Name = "nombretiempo";
            this.nombretiempo.Size = new System.Drawing.Size(123, 20);
            this.nombretiempo.TabIndex = 27;
            // 
            // Data
            // 
            this.Data.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Data.Location = new System.Drawing.Point(406, 255);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(209, 117);
            this.Data.TabIndex = 28;
            this.Data.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Data_CellContentClick);
            // 
            // invitar
            // 
            this.invitar.BackColor = System.Drawing.Color.LightPink;
            this.invitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invitar.ForeColor = System.Drawing.Color.DimGray;
            this.invitar.Location = new System.Drawing.Point(468, 387);
            this.invitar.Name = "invitar";
            this.invitar.Size = new System.Drawing.Size(75, 23);
            this.invitar.TabIndex = 29;
            this.invitar.Text = "Invitar";
            this.invitar.UseVisualStyleBackColor = false;
            this.invitar.Click += new System.EventHandler(this.invitar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Salmon;
            this.label3.Location = new System.Drawing.Point(50, 340);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 16);
            this.label3.TabIndex = 30;
            this.label3.Text = "Escribe tu mensaje";
            // 
            // Chat
            // 
            this.Chat.BackColor = System.Drawing.Color.LightPink;
            this.Chat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chat.ForeColor = System.Drawing.Color.DimGray;
            this.Chat.Location = new System.Drawing.Point(91, 387);
            this.Chat.Name = "Chat";
            this.Chat.Size = new System.Drawing.Size(75, 23);
            this.Chat.TabIndex = 31;
            this.Chat.Text = "Enviar";
            this.Chat.UseVisualStyleBackColor = false;
            this.Chat.Click += new System.EventHandler(this.Chat_Click);
            // 
            // chatmensaje
            // 
            this.chatmensaje.AutoSize = true;
            this.chatmensaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chatmensaje.ForeColor = System.Drawing.Color.Black;
            this.chatmensaje.Location = new System.Drawing.Point(252, 360);
            this.chatmensaje.Name = "chatmensaje";
            this.chatmensaje.Size = new System.Drawing.Size(96, 16);
            this.chatmensaje.TabIndex = 32;
            this.chatmensaje.Text = "chatmensaje";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Salmon;
            this.label5.Location = new System.Drawing.Point(230, 340);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 16);
            this.label5.TabIndex = 33;
            this.label5.Text = "Tu oponente ha dicho";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label4.Location = new System.Drawing.Point(54, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(211, 20);
            this.label4.TabIndex = 34;
            this.label4.Text = "Inicia sesion o registrate!";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label6.Location = new System.Drawing.Point(28, 305);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(245, 20);
            this.label6.TabIndex = 35;
            this.label6.Text = "Comunicate con tu oponente!";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label7.Location = new System.Drawing.Point(356, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(178, 20);
            this.label7.TabIndex = 36;
            this.label7.Text = "Consulta informacion";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label8.Location = new System.Drawing.Point(356, 225);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(259, 20);
            this.label8.TabIndex = 37;
            this.label8.Text = "Invita a otro jugador conectado";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 422);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.chatmensaje);
            this.Controls.Add(this.Chat);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.invitar);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.nombretiempo);
            this.Controls.Add(this.nombrepuntuacion);
            this.Controls.Add(this.nombre2);
            this.Controls.Add(this.chattxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.jugador1);
            this.Controls.Add(this.nombre1);
            this.Controls.Add(this.consultas);
            this.Controls.Add(this.tiempo);
            this.Controls.Add(this.puntuacion);
            this.Controls.Add(this.ganador);
            this.Controls.Add(this.signup);
            this.Controls.Add(this.loging);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.user);
            this.Controls.Add(this.usertxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.iptxt);
            this.Controls.Add(this.desconectar);
            this.Controls.Add(this.conectar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button conectar;
        private System.Windows.Forms.Button desconectar;
        private System.Windows.Forms.TextBox iptxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox usertxt;
        private System.Windows.Forms.Label user;
        private System.Windows.Forms.Label pass;
        private System.Windows.Forms.TextBox passtxt;
        private System.Windows.Forms.Button loging;
        private System.Windows.Forms.Button signup;
        private System.Windows.Forms.RadioButton ganador;
        private System.Windows.Forms.RadioButton puntuacion;
        private System.Windows.Forms.RadioButton tiempo;
        private System.Windows.Forms.Button consultas;
        private System.Windows.Forms.TextBox nombre1;
        private System.Windows.Forms.Label jugador1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox chattxt;
        private System.Windows.Forms.TextBox nombre2;
        private System.Windows.Forms.TextBox nombrepuntuacion;
        private System.Windows.Forms.TextBox nombretiempo;
        private System.Windows.Forms.DataGridView Data;
        private System.Windows.Forms.Button invitar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Chat;
        private System.Windows.Forms.Label chatmensaje;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

